find_weather_details Project by Rohan Shinde. 
For extra information you can contact with me using following id's
Email id = rohanshinde7353@gmail.com
Linkdin id = https://www.linkedin.com/in/rohan-shinde-43a209180
